<!-- pagination -->
<div class="pagination">
	<?php lwp_pagination(); ?>
</div>
<!-- /pagination -->
