<!-- search -->
<!--<form class="search" method="get" action="--><?php //echo home_url(); ?><!--" role="search">-->
<!--	<input class="search-input" type="search" name="s" placeholder="--><?php //_e( 'Search', THEME_OPT ); ?><!--">-->
<!--	<button class="search-submit" type="submit" role="button"><i class="fa fa-search" aria-hidden="true"></i>--><?php //_e( 'Search', THEME_OPT ); ?><!--</button>-->
<!--</form>-->
<!-- /search -->
<!-- search -->
<form>
    <div class="search"  method="get" action="<?php echo home_url(); ?>" role="search">
        <input class="search-input" type="search" name="s" placeholder="<?php _e( 'Search', THEME_OPT ); ?>">
        <button class="search-submit" type="submit" role="button"><i class="fa fa-search" aria-hidden="true"></i></button>
    </div>
</form>

<!-- /search -->
<style>

</style>